<?php
$servername="127.0.0.1";
$user = "appUser";
$password="AppMobile123456$$";
$db="appMobile";
$port=3306;

$conn= new mysqli($servername,$user,$password,$db,$port);

if(!$conn){
	die("Error de conexion");
}
?>
