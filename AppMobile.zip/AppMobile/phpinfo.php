<?php
// Configurar la zona horaria a Veracruz, México
date_default_timezone_set('America/Mexico_City');

// Obtener la fecha y hora actual
$fechaActual = date("Y-m-d H:i:s");

// Imprimir la fecha y hora actual
echo $fechaActual;

