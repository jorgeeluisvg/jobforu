<?php
class Profile {
    public $id_user;
    public $Nombre;
    public $Apellido;
    public $Ubicacion;
    public $Descripcion;
    public $Oficio;
    public $url_imagen;

    public function __construct($id_user, $Nombre,$Apellido,$Ubicacion,$Descripcion,$Oficio,$url_imagen) {
        $this->id_user = $id_user;
        $this->Nombre = $Nombre;
        $this->Apellido = $Apellido;
        $this->Ubicacion = $Ubicacion;
        $this->Descripcion = $Descripcion;
        $this->Oficio = $Oficio;
        $this->url_imagen = $url_imagen;
    }
}

class ProfileReview {
    public $id_user;
    public $Nombre;
    public $Apellido;
    public $Ubicacion;
    public $Descripcion;
    public $Oficio;
    public $review;
    public $url_imagen;
    public $telefono;

    public function __construct($id_user, $Nombre,$Apellido,$Ubicacion,$Descripcion,$Oficio,$review,$url_imagen,$telefono) {
        $this->id_user = $id_user;
        $this->Nombre = $Nombre;
        $this->Apellido = $Apellido;
        $this->Ubicacion = $Ubicacion;
        $this->Descripcion = $Descripcion;
        $this->Oficio = $Oficio;
        $this->review = $review;
        $this->url_imagen = $url_imagen;
        $this->telefono = $telefono;
    }
}

class Review {
    public $review;
    public $comentario;
    public $nombre_usuario;
    public $apellido_usuarios;

    public function __construct($review,$comentario,$nombre_usuario,$apellido_usuarios) {
        $this->review               = $review;
        $this->comentario           = $comentario;
        $this->nombre_usuario       = $nombre_usuario;
        $this->apellido_usuarios    = $apellido_usuarios;
    }
}

class ProfileByTAG {
    public $id_user;
    public $Nombre;
    public $Apellido;
    public $Ubicacion;
    public $url_imagen;
    public $descripcion;

    public $oficio;
    public function __construct($id_user, $Nombre,$Apellido,$Ubicacion,$url_imagen,$descripcion,$oficio) {
        $this->id_user = $id_user;
        $this->Nombre = $Nombre;
        $this->Apellido = $Apellido;
        $this->Ubicacion = $Ubicacion;
        $this->url_imagen = $url_imagen;
	$this->descripcion=$descripcion;
	$this->oficio=$oficio;
    }
}
