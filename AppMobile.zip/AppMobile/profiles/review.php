<?php
require "../config/database.php";
require "dbfun/dbfunciones.php";
require "Controllers/Controllers.php";
require "Model/Profile.php";

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case "PUT":
        $jsonData = file_get_contents('php://input');
        $data = json_decode($jsonData);
        CreateReview($conn,$data);
        break;
    default:
        header('HTTP/1.1 404 Not Found');
        echo 'NOT SUPPORTED METHOD ';
        break;
}

