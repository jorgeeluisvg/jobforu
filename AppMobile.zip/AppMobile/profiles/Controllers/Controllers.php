<?php

function GetProfiles($conn){
    $response = json_encode(ObtenerPerfiles($conn));
    header("Content-Type: application/json");
	$response ="{\"response\": 200, \"Profiles\": $response }";
	echo $response;
}

function CreateReview($conn,$data){

    if ($data!=null)
    {
        $id_user            = $data->id_user;
        $id_user_post       = $data->id_user_post;
        $review             = $data->review;
        $comentario         = $data->comentario;
        $resp = CrearReview($conn,$id_user,$id_user_post,$review,$comentario);
        header("Content-Type: application/json");
        echo "{\"response\": 200,\"content\": $resp}";

    }else{
        header("Content-Type: application/json");
        $jsonData = "{\"response\": 505,\"content\": \"Faltan campos\"}";
        echo $jsonData;
    }
}

function CreateProfile($conn,$data){

    if ($data!=null)
    {
        $id_user 	    = $data->id_user;
        $nombre 	    = $data->nombre;
        $apellido	    = $data->apellido;
        $ubicacion 	    = $data->ubicacion;
        $oficio             = $data->oficio;
        $descripcion        = $data->descripcion;
        $url_imagen 	    = $data->url_imagen;
	$telefono	    =$data->telefono;
        $resp = CrearPerfil($conn,$id_user,$nombre,$apellido,$ubicacion,$descripcion,$oficio,$url_imagen,$telefono);
        header("Content-Type: application/json");
        echo "{\"response\": 200,\"content\": $resp}";

    }else{
        header("Content-Type: application/json");
        $jsonData = "{\"response\": 505,\"content\": \"Faltan campos\"}";
        echo $jsonData;
    }
}

function GetProfile($conn,$id_user){
    try{
        $responseProfile = json_encode(ObtenerPerfil($conn,$id_user));
        $responseReviews = json_encode(ObtenerReviews($conn,$id_user));
        header("Content-Type: application/json");
	$response ="{\"response\": 200, \"Profile\": $responseProfile , \"Reviews\": $responseReviews }";
	echo $response;

    }catch(Exception $e){
        header("Content-Type: application/json");
        $response ="{\"response\": 500, \"Message\": ".$e->getMessage()." }";
        echo $response;
    }
}

function GetProfilesByTAG($conn,$tag,$loc){
    $response = json_encode(ObtenerPerfilesByTag($conn,$tag,$loc));
    header("Content-Type: application/json");
	$response ="{\"response\": 200, \"Profiles\": $response }";
	echo $response;
}

function ActualizarProfile($conn,$id_user,$nombre,$apellido,$ubicacion,$descripcion,$oficio,$url){
    $resp = ActualizarPerfil($conn,$id_user,$nombre,$apellido,$ubicacion,$descripcion,$oficio,$url);
     header("Content-Type: application/json");
     echo "{\"response\": 200,\"content\": $resp}";
}
