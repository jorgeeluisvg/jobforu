<?php
require "../config/database.php";
require "dbfun/dbfunciones.php";
require "Controllers/Controllers.php";
require "Model/Profile.php";

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case "GET":

       // echo "GET";
       if(isset($_GET["id_user"])){
            GetProfile($conn,$_GET["id_user"]);
       }else if(isset($_GET["tag"])){
		$loc           = isset($_GET['location']) ? "Ubicacion LIKE '%".$_GET["location"]."%'" : '1=1';
            GetProfilesByTAG($conn,$_GET["tag"],$loc);
       }else {
            GetProfiles($conn);
       }
       break;

    case 'PUT':
        $jsonData = file_get_contents('php://input');
        $data = json_decode($jsonData);
        CreateProfile($conn,$data);
        break;
    case 'POST':
	$data = empty($_POST) ? json_decode(file_get_contents('php://input'), true) : $_POST;
        $id_user        = $data['id_user'];
        $nombre         = !empty($data['nombre']) ? "Nombre='".$data['nombre']."'" : "Nombre=Nombre";
        $apellido       = !empty($data['apellido']) ? "Apellido='".$data['apellido']."'" : "Apellido=Apellido";
	$ubicacion	= !empty($data['ubicacion']) ? "Ubicacion='".$data['ubicacion']."'" : "Ubicacion=Ubicacion";
	$descripcion	= !empty($data['descripcion']) ? "Descripcion='".$data['descripcion']."'" : "Descripcion=Descripcion";
	$oficio		= !empty($data['oficio']) ? "Oficio='".$data['oficio']."'" : "Oficio=Oficio";//
	$url		= !empty($data['url_imagen']) ? "url_imagen='".$data['url_imagen']."'" : "url_imagen=url_imagen";
	ActualizarProfile($conn,$id_user,$nombre,$apellido,$ubicacion,$descripcion,$oficio,$url);
	break;
    default:
        header('HTTP/1.1 404 Not Found');
        echo 'NOT SUPPORTED METHOD ';
        break;
}

