<?php

function ObtenerPerfiles($conn){
    $sql = "SELECT id_user,Nombre,Apellido,Ubicacion,Descripcion,Oficio,url_imagen FROM Usuarios WHERE Oficio!='' ORDER BY RAND() LIMIT 5";
    $consulta = $conn->query($sql);
    $lista=array();
    while($row = $consulta->fetch_assoc()){
        $lista[] = new Profile($row["id_user"],$row["Nombre"],$row["Apellido"],$row["Ubicacion"],$row["Descripcion"],$row["Oficio"],$row["url_imagen"]);
    }
    return $lista;
}

function CrearReview($conn,$id_user,$id_user_post,$review,$comentario){
        $sql="INSERT INTO Review (id_user,id_user_post,review,comentario) VALUES ('$id_user','$id_user_post',$review,'$comentario')";

    if ($conn->query($sql) === TRUE) {
        $lista=array();
        $lista["msg"]="review insertada";
        $resp = json_encode($lista);
        return $resp;
    } else {
	$lista=array();
	$lista["msg"]="review error";
        $resp = json_encode($lista);
        return $resp;
    }
}

function CrearPerfil($conn,$id_user,$nombre,$apellido,$ubicacion,$descripcion,$oficio,$url,$telefono){
    $sql = "INSERT INTO Usuarios (id_user,Nombre,Apellido,Ubicacion,Descripcion,Oficio,url_imagen,Telefono) VALUES ('$id_user','$nombre','$apellido','$ubicacion','$descripcion','$oficio','$url','$telefono')";
    if ($conn->query($sql) === TRUE) {
        $lista=array();
        $lista[] = new Profile($id_user,$nombre,$apellido,$ubicacion,$descripcion,$oficio,$url);
        $lista["telefono"]=$telefono;
        $resp = json_encode($lista);
        return $resp;
    } else {
        return $conn;
    }
}

function ObtenerPerfil($conn,$id_user){
    $sql = "SELECT U.id_user,Nombre,Apellido,Ubicacion,Descripcion,Oficio,AVG(R.review) as review,url_imagen,Telefono FROM Usuarios U LEFT JOIN Review R ON U.id_user= R.id_user WHERE U.id_user='$id_user' GROUP BY R.id_user";
    $consulta = $conn->query($sql);
    $lista=array();
    while($row = $consulta->fetch_assoc()){
        $lista[] = new ProfileReview($row["id_user"],$row["Nombre"],$row["Apellido"],
        $row["Ubicacion"],$row["Descripcion"],$row["Oficio"],$row["review"],$row["url_imagen"],
        $row["Telefono"]);
    }
    return $lista;
}

function ObtenerReviews($conn,$id_user){
    $sql = "SELECT review,comentario,U.Nombre,U.Apellido FROM Review R LEFT JOIN Usuarios U ON R.id_user_post = U.id_user WHERE R.id_user='$id_user' GROUP BY R.id_user";
    $consulta = $conn->query($sql);
    $lista=array();
/*    while($row = $consulta->fetch_assoc()){
        $lista[] = new Review($row["review"],$row["comentario"],$row["Nombre"],$row["Apellido"]);
    }
 */   return $lista;
}

function ObtenerPerfilesByTag($conn,$tag,$loc){
    $sql = "SELECT id_user,Nombre,Apellido,Ubicacion,Descripcion,url_imagen,Oficio FROM Usuarios WHERE Oficio LIKE '$tag%' AND $loc";
    $consulta = $conn->query($sql);
    $lista=array();
    while($row = $consulta->fetch_assoc()){
        $lista[] = new ProfileByTAG($row["id_user"],$row["Nombre"],$row["Apellido"],$row["Ubicacion"],$row["url_imagen"],$row["Descripcion"],$row["Oficio"]);
    }
    return $lista;
}


function ActualizarPerfil($conn,$id_user,$nombre,$apellido,$ubicacion,$descripcion,$oficio,$url){
    $sql = "UPDATE Usuarios SET $nombre, $apellido, $ubicacion,$descripcion,$oficio,$url WHERE id_user='$id_user'";
    
    if ($conn->query($sql) === TRUE) {
//        $lista=array();
        //$lista[] = new Profile($id_user,$nombre,$apellido,$ubicacion,$descripcion,$oficio,$url);
	$lista["msg"]="Actualizado con exito";
//        $resp = json_encode($lista);
        return json_encode($lista);
    } else {
        return $conn;
    }
}

