<?php
class Mensaje {
    public $mensaje;
    public $id_sender;
    public $fecha;

    public function __construct($mensaje, $id_sender,$fecha) {
        $this->mensaje = $mensaje;
        $this->id_sender = $id_sender;
        $this->fecha = $fecha;
    }
}
class Conversaciones {
    public $id_conv;
    public $id_user;
    public $nombre;
    public $apellido;
    public $url_imagen;
    public $telefono;
    public $oficio;

    public function __construct($id_conv, $id_user,$nombre,$apellido,$url_imagen,$telefono,$oficio) {
        $this->id_conv = $id_conv;
        $this->id_user = $id_user;
        $this->nombre = $nombre;
        $this->apellido = $apellido;
        $this->url_imagen = $url_imagen;
        $this->telefono = $telefono;
	$this->oficio = $oficio;
    }
}
