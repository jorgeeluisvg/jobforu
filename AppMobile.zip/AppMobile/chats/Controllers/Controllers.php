<?php

function ObtenerResponse($conn,$user1,$user2){
    $response = obtenerConversacion($conn,$user1,$user2);
    $messageResponse= json_encode(ObtenerMensajes($conn,$response));
    header("Content-Type: application/json");
	$response ="{\"response\": 200, \"id_conv\": $response, \"Messages\" : $messageResponse }";
	echo $response;
}

function insertarMessage($conn,$data){
    if ($data!=null)
    {
        $id_conv 	 = $data->id_conv;
        $id_sender 	 = $data->id_sender;
        $mensaje	 = $data->mensaje;
        $resp = InsertarMensaje($conn,$id_conv,$id_sender,$mensaje);
        header("Content-Type: application/json");
        echo "{\"response\": 200,\"content\": $resp}";

    }else{
        header("Content-Type: application/json");
        $jsonData = "{\"response\": 505,\"content\": \"Faltan campos\"}";
        echo $jsonData;
    }

}

function ObtenerConversacionResponse($conn,$user1){
    $messageResponse= json_encode(obtenerConversaciones($conn,$user1));
    header("Content-Type: application/json");
	$response ="{\"response\": 200, \"Conversaciones\" : $messageResponse }";
	echo $response;
}
