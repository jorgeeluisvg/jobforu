<?php
require "../config/database.php";
require "dbfun/dbfunciones.php";
require "Controllers/Controllers.php";
require "Model/Mensaje.php";


$method = $_SERVER['REQUEST_METHOD'];


switch ($method) {
    case "GET":
	if(isset($_GET["id_user_1"]) && isset($_GET["id_user_2"])){
        	ObtenerResponse($conn,$_GET["id_user_1"],$_GET["id_user_2"]);
	}else if(isset($_GET["id_user"])){
//	echo $_GET["id_user"];	
            ObtenerConversacionResponse($conn,$_GET["id_user"]);
        }
	else{
		header('HTTP/1.1 404 Not Found');
        	echo 'NOT FOUND ';
	}
        	break;

    case 'PUT':
        $jsonData = file_get_contents('php://input');
        $data = json_decode($jsonData);
        insertarMessage($conn,$data);
        break;

    default:
        header('HTTP/1.1 404 Not Found');
        echo 'NOT SUPPORTED METHOD ';
        break;
}

