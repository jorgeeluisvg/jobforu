<?php

function obtenerConversacion($conn,$parametro1,$parametro2){
    
    $sql = "CALL VerificarConversacionYCrearRegistro(?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $parametro1, $parametro2);
    $stmt->execute();

    // Obtener resultados
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $idConversacion = $row['id_conversacion'];
    return $idConversacion;
}

function ObtenerMensajes($conn,$param){
    $sql = "SELECT id_user_sender,mensaje,fecha FROM Mensajes WHERE id_conversacion=".$param;
    $consulta = $conn->query($sql);
    $lista=array();
    while($row = $consulta->fetch_assoc()){
        $lista[] = new Mensaje($row["mensaje"],$row["id_user_sender"],$row["fecha"]);
    }
    return $lista;
}

function InsertarMensaje($conn,$id_conv,$id_sender,$mensaje){
date_default_timezone_set('America/Mexico_City');

$fechaActual = date("Y-m-d H:i:s");

    $sql = "INSERT INTO Mensajes VALUES ($id_conv, '$id_sender','$mensaje','$fechaActual')";
    if ($conn->query($sql) === TRUE) {
        $lista=array();
        $lista[] = new Mensaje($mensaje,$id_sender,$fechaActual);
        $resp = json_encode($lista);
        return $resp;
    } else {
        return $conn;
    }
}


function obtenerConversaciones($conn,$parametro1){
    
    $sql = "CALL ObtenerRegistrosConversacion(?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $parametro1);
    $stmt->execute();

    // Obtener resultados
    $result = $stmt->get_result();
    $lista=array();
    while($row = $result->fetch_assoc()){
        $lista[] = new Conversaciones($row["id"],$row["id_user"],$row["Nombre"],$row["Apellido"],$row["url_imagen"],$row["Telefono"],$row["Oficio"]);
    }
    return $lista;
}
