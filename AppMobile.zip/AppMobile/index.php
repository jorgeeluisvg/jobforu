<?php

// Verifica si el encabezado "Authorization" está presente
if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
    // Obtiene el valor del encabezado "Authorization"
    $authorizationHeader = $_SERVER['HTTP_AUTHORIZATION'];

    // Verifica si el encabezado comienza con "Bearer "
    if (strpos($authorizationHeader, 'Bearer ') === 0) {
        // Extrae el token después de "Bearer "
        $token = substr($authorizationHeader, 7);

        // Verifica si el token es el valor esperado
        if ($token === 'Tu-Valor-Esperado') {
            // El encabezado Bearer es válido, ejecuta tu código aquí
            echo 'Encabezado Bearer válido. El código se ejecuta.';
        } else {
            // El token no es válido
            header('HTTP/1.1 403 Forbidden');
            echo 'Token no válido';
            exit();
        }
    } else {
        // El encabezado no comienza con "Bearer "
        header('HTTP/1.1 403 Forbidden');
        echo 'Encabezado no válido';
        exit();
    }
} else {
    // El encabezado "Authorization" no está presente
    header('HTTP/1.1 403 Forbidden');
    echo 'Acceso no autorizado';
    exit();
}

// Resto de tu código aquí...
